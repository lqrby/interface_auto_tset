{
    "common": {
        
        "appVersion": "",
        "deviceGroupId": "",
        "userId": "0002020072110365418500",
        "projectId": "hn",
        "device": {
            "udid": "",
            "deviceId": "",
            "mac": ""
        },
        "channelId": "hn",
        "token": ""
    },
    "options": {
        "rechargeId":"1001",
        "appVersion": "",
        "rechargeSource": "6",
        "deviceGroupId": "",
        "ip": "",
        "sign": "d41d8cd98f00b204e9800998ecf8427e",
        "description": "充值",
        "userId": "0002020072110365418500",
        "channelId": "",
        "gemstone": 15
    }
}